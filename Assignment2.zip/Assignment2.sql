use assignment

select * from Jomato

--1)Create a user-defined functions to stuff the Chicken into �Quick Bites�. Eg: �Quick
--Chicken Bites�.

create function udf_stuff
(
	@RestaurantType char(200)
)
returns char(200)
as
begin
	Declare @updated_name varchar(200)
	select @updated_name = Restauranttype FROM jomato J where RestaurantName=@RestaurantType;
	if (@updated_name='Quick Bites')
	set @updated_name='Quick Chicken Bites';
	
	RETURN @updated_name;
end

select dbo.udf_stuff('Quick Bites')

-- 2) Use the function to display the restaurant name and cuisine type which has the
--maximum number of rating
create function udf_rest_cuisne_type()
returns table
return 
(
	SELECT RestaurantName,CuisinesType
	from
	Jomato
	where Rating in (select max(Rating) from Jomato)
)


select * from udf_rest_cuisne_type()

--3)Create a Rating Status column to display the rating as �Excellent� if it has more the 4
--start rating, �Good� if it has above 3.5 and below 5 star rating, �Average� if it is above 3
--and below 3.5 and �Bad� if it is below 3 star rating.

Alter table Jomato
add rating_status varchar(200);

UPDATE Jomato
SET rating_status = CASE
                      WHEN rating > 4 THEN 'Excellent'
                      WHEN rating > 3.5 THEN 'Good'
                      WHEN rating > 3 THEN 'Average'
                      ELSE 'Bad'
                   END;

select rating_status from Jomato

select * from Jomato
--4) Find the Ceil, floor and absolute values of the rating column and display the current date
--and separately display the year,month name and day

select Rating, CEILING(Rating) , FLOOR(Rating) , GETDATE(), YEAR(GETDATE()), DATENAME(MM,GETDATE()),DATENAME(weekday,GETDATE())
from Jomato

SELECT * from Jomato

-- 5)Display the restaurant type and average total cost using rollup
select RestaurantType , SUM(AverageCost) as TotalAvgCost
from Jomato 
group by rollup(RestaurantType)


