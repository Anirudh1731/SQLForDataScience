use assignment

select * from Jomato

-- 1) Create a stored procedure to display the restaurant name, type and cuisine where the
--table booking is not zero

create procedure display_details
as 
begin
SELECT RestaurantName,RestaurantType,CuisinesType 
from Jomato
where TableBooking <> 0
end

execute display_details

--2)Create a transaction and update the cuisine type �Cafe� to �Cafeteria�. Check the result
--and rollback it

BEGIN TRANSACTION;

UPDATE Jomato 
set CuisinesType= 'Cafeteria'
where CuisinesType='Cafe'

SELECT * FROM Jomato
ROLLBACK TRAN

--3 ) Generate a row number column and find the top 5 areas with the highest rating of
--restaurants
SELECT TOP 5 * , ROW_NUMBER () OVER (ORDER BY RATING DESC)  FROM Jomato

--4)Use the while loop to display the 1 to 50

DECLARE @Counter INT 
SET @Counter=1
WHILE ( @Counter <= 50)
BEGIN
    PRINT @Counter
    SET @Counter  = @Counter  + 1
END

--5) Write a query to Create a Top rating view to store the generated top 5 highest rating of restaurants

select * from Jomato

create view TopRatingView1
as
(
	SELECT TOP 5 * FROM
	(
		SELECT *,DENSE_RANK() OVER (ORDER BY RATING DESC) as denserank FROM Jomato
	) s
) 

--or 
select top 5 * 
from 
Jomato 
order by Rating desc

select * from TopRatingView1

--6)
create trigger insertion on Jomato
after insert
as
begin
print('Data is inserted')
end
